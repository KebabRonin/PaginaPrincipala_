1. pune libbgi.a in folderul lib
2. graphics.h si winbgim.h in include din MinGW (MinGW in Program Files > Codeblocks > MinGW)
3. fa un proiect nou in codeblocks, copie main si highscore in folder